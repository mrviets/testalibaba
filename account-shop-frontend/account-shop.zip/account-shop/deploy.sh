#!/bin/bash

# Script deployment cho Account Shop
echo "🚀 Bắt đầu deployment Account Shop..."

# Cài đặt dependencies
echo "📦 Cài đặt dependencies..."
composer install --optimize-autoloader --no-dev

# Tạo key nếu chưa có
if [ ! -f .env ]; then
    echo "📝 Tạo file .env..."
    cp .env.example .env
    php artisan key:generate
fi

# Chạy migrations
echo "🗄️ Chạy migrations..."
php artisan migrate --force

# Seed dữ liệu mẫu (nếu cần)
read -p "Bạn có muốn seed dữ liệu mẫu không? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "🌱 Seeding dữ liệu mẫu..."
    php artisan db:seed --class=ProductSeeder
fi

# Optimize cho production
echo "⚡ Optimize cho production..."
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Cấu hình quyền thư mục
echo "🔐 Cấu hình quyền thư mục..."
chmod -R 755 .
chmod -R 775 storage
chmod -R 775 bootstrap/cache

# Tạo admin user
read -p "Bạn có muốn tạo admin user không? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "👤 Tạo admin user..."
    php artisan make:filament-user
fi

echo "✅ Deployment hoàn thành!"
echo "🌐 Truy cập admin panel tại: /admin"
echo "🏠 Truy cập trang chủ tại: /"
