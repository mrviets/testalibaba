#!/bin/bash

# Deploy script cho DirectAdmin - dinhquocviet.space
echo "🚀 Deploy Account Shop lên DirectAdmin..."

# Kiểm tra môi trường
if [ ! -f "composer.json" ]; then
    echo "❌ Không tìm thấy composer.json. Hãy chạy script trong thư mục project."
    exit 1
fi

# 1. Backup database hiện tại (nếu có)
echo "📦 Backup database..."
mysqldump -u admin_dinhquocvietshop -pgYAqs4QqphdJGEj8UvtV admin_dinhquocvietshop > backup_$(date +%Y%m%d_%H%M%S).sql 2>/dev/null || echo "⚠️  Database chưa có dữ liệu hoặc backup failed"

# 2. Cấu hình môi trường production
echo "⚙️  Cấu hình môi trường production..."
if [ -f ".env.production" ]; then
    cp .env.production .env
    echo "✅ Đã copy .env.production thành .env"
else
    echo "⚠️  Không tìm thấy .env.production, tạo .env mới..."
    cat > .env << 'EOF'
APP_NAME="Account Shop"
APP_ENV=production
APP_KEY=base64:4dUWfFT9QPLFz5MpLhgAOoYrlxf6tAjthSLRSJvECCo=
APP_DEBUG=false
APP_URL=https://dinhquocviet.space

LOG_CHANNEL=stack
LOG_DEPRECATIONS_CHANNEL=null
LOG_LEVEL=error

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=admin_dinhquocvietshop
DB_USERNAME=admin_dinhquocvietshop
DB_PASSWORD=gYAqs4QqphdJGEj8UvtV

BROADCAST_DRIVER=log
CACHE_DRIVER=file
FILESYSTEM_DISK=local
QUEUE_CONNECTION=sync
SESSION_DRIVER=file
SESSION_LIFETIME=120

MEMCACHED_HOST=127.0.0.1

REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379

MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your_email@gmail.com
MAIL_PASSWORD=your_app_password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS="noreply@dinhquocviet.space"
MAIL_FROM_NAME="Account Shop"
EOF
fi

# 3. Cài đặt dependencies
echo "📥 Cài đặt Composer dependencies..."
if command -v composer &> /dev/null; then
    composer install --optimize-autoloader --no-dev --no-interaction
else
    echo "❌ Composer không tìm thấy. Hãy cài đặt Composer trước."
    exit 1
fi

# 4. Generate key nếu cần
if grep -q "APP_KEY=$" .env || grep -q "APP_KEY=base64:$" .env; then
    echo "🔑 Generate application key..."
    php artisan key:generate --force
fi

# 5. Kiểm tra kết nối database
echo "🔍 Kiểm tra kết nối database..."
php artisan migrate:status 2>/dev/null || {
    echo "❌ Không thể kết nối database. Kiểm tra thông tin trong .env"
    exit 1
}

# 6. Chạy migrations
echo "🗄️  Chạy database migrations..."
php artisan migrate --force

# 7. Seed dữ liệu mẫu
echo "🌱 Seed dữ liệu mẫu..."
php artisan db:seed --class=ProductSeeder --force

# 8. Cấu hình quyền thư mục cho DirectAdmin
echo "🔒 Cấu hình quyền thư mục..."
find . -type f -exec chmod 644 {} \;
find . -type d -exec chmod 755 {} \;
chmod -R 775 storage
chmod -R 775 bootstrap/cache
chmod 644 .env

# 9. Optimize cho production
echo "⚡ Optimize cho production..."
php artisan config:cache
php artisan route:cache
php artisan view:cache

# 10. Clear cache cũ
php artisan cache:clear

# 11. Tạo symlink cho storage (nếu cần)
if [ ! -L "public/storage" ]; then
    echo "🔗 Tạo storage symlink..."
    php artisan storage:link
fi

echo ""
echo "✅ Deploy hoàn thành!"
echo ""
echo "📋 Checklist sau deploy:"
echo "1. ✅ Database đã được migrate"
echo "2. ✅ Dữ liệu mẫu đã được seed"
echo "3. ✅ Cache đã được optimize"
echo "4. ✅ Quyền thư mục đã được cấu hình"
echo ""
echo "🔧 Bước tiếp theo:"
echo "1. Tạo admin user: php artisan make:filament-user"
echo "2. Cấu hình DirectAdmin trỏ DocumentRoot đến thư mục public/"
echo "3. Cấu hình SSL certificate"
echo ""
echo "🌐 Truy cập website:"
echo "- Frontend: https://dinhquocviet.space/"
echo "- Admin Panel: https://dinhquocviet.space/admin"
echo ""
echo "📝 Ghi chú:"
echo "- File backup database: backup_$(date +%Y%m%d_%H%M%S).sql"
echo "- Log file: storage/logs/laravel.log"
